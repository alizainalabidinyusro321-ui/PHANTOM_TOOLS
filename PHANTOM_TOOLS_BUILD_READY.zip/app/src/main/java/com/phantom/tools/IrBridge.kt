package com.phantom.tools // ganti sesuai package kamu

import android.content.Context
import android.hardware.ConsumerIrManager
import android.webkit.JavascriptInterface

class IrBridge(private val ctx: Context) {
    private val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    @JavascriptInterface
    fun hasIr(): Boolean = ir?.hasIrEmitter() == true

    @JavascriptInterface
    fun sendIr(freq: Int, pattern: String): Boolean {
        val emitter = ir ?: return false
        if (!emitter.hasIrEmitter()) return false
        val arr = pattern.split(",").map { it.trim().toInt() }.toIntArray()
        return try { emitter.transmit(freq, arr); true } catch (e: Exception) { false }
    }
}